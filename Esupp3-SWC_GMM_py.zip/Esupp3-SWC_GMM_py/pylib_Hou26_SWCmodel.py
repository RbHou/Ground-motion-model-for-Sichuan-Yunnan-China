#####################################################################################################
#                                                                                                   #
#   This program is used to compute the median of the Hou et al. (2026) ground motion model for     #
#   the Sichuan-Yunnan region of Southwest China published in Bulletin of Earthquake Engineering    #
#   For any issues, please contact Hou with email ruibin90816@163.com                               #
#                                                                                                   #
#####################################################################################################

import os, time
import numpy as np
import matplotlib.pyplot as plt 

def GetKey(key):
    return '%.3f'%(key)


class GMM_Hou25_SWC:
    """
    Class for Xing 2021 SWC model 
    """
    def __init__(self):
        self.filepth = os.path.join(os.path.dirname(__file__)) 
        self.CoefFile = os.path.join(self.filepth,'pylib_Hou26_SWCmodel_param.csv')
        self.Coefs = {}
        self.ReadModelCoefs()
        
        # put some period independent coefs here 
        self.Rref = 10.0 
        self.Mref = 6.5 
        self.Depthref = 1.0
        self.SCs = ['I','II','III','IV', 1, 2, 3, 4]
        self.faults = [1,2,3,4,'RV','NM','SS','U']
        self.SCNLs = [0,1]
    #
    #
    def __call__(self, M, Dist, SC, T, Mech=1, Ftype=None, depth=1.0, SCNL=1, CoefTerms={'terms':(1,1,1),'NewCoefs':None}):
        """
        Compute IM for single period
        required inputs:
        M, Depth, Dist, vDist, SC, T
        rake: rake angle (degree), default is None (Unspecified fault type)
        or give Mech instead of rake
        Mech: 
            1: reverse
            2: normal
            3: strike
            else: 4 unspecified (U=1) (Default)
        Ftype = 'U', or 'SS', or 'RV', or 'NM'
        """
        # ==================
        # Input variables
        # ==================
        self.M = float(M)               # moment magnitude
        self.depth = float(depth)       # focal depth
        self.Dist = float(Dist)         # source distance (km)
        self.SC = SC                    # site class
        self.Mech = Mech


        terms = CoefTerms['terms']
        NewCoefs = CoefTerms['NewCoefs']

        
        # check inputs
        if T in self.periods:
            self.T = T
        else:
            print ('T is not in periods list, try to interpolate')
            raise ValueError
    
        if self.M == None or self.M < 0:
            print ('Moment magnitude must be a postive number')
            raise ValueError

        if self.Dist == None or self.Dist < 0:
            print ('Source distance must be a non-negative number')
            raise ValueError
        
        if self.depth == None or self.depth < 0:
            print ('focal depth must be a non-negative number')
            raise ValueError
        
        if self.Dist < self.depth:
            print ('Source distance must be larger than focal depth')
            # raise ValueError
        
        if SC in self.SCs :
            self.SC = SC
        else:
            print ("SC must be one of 1, 2, 3, 4 or 'I', 'II', 'III', 'IV'")
            raise ValueError
        
        if Mech == None and Ftype == None:
            print ('either (U,SS,NM,RV) or focal mechanics should be provided')
            raise ValueError
        else: 
            if Ftype != None: 
                self.U = 1*(Ftype == 'U')
                self.SS = 1*(Ftype == 'SS')
                self.NM = 1*(Ftype == 'NM')
                self.RV = 1*(Ftype == 'RV')
            if Mech != None:
                self.U = 1*(Mech==0)
                self.RV = 1*(Mech==1)
                self.SS = 1*(Mech==2)
                self.NM = 1*(Mech==3)
        
        if SCNL in self.SCNLs:
            self.SCNL = SCNL
        else:
            print ('Nonlinearity of Site Class must be 0 or 1! 0 is for elasticity, while 1 is for nonlinearity.')
            raise ValueError
        
        # modify the coefficients (only update Coefs given by NewCoefs (at self.T))
        if NewCoefs != None:
            Tkey = GetKey( self.T )
            NewCoefKeys = NewCoefs.keys()
            for key in NewCoefKeys:
                self.Coefs[Tkey][key] = NewCoefs[key]
        
        # ======================
        # begin to compute IM
        # ======================
        #
        # Median ground motion [PGA & SA: g]
        IM = self.compute_im(terms=terms)
        
        #
        # standard deviation [same unit as median GM]
        sigmaT, tau, sigma, sigmaTSC, tauSC, sigmaSC, siteSigmaT, siteSigma=self.compute_std()
        
        return IM, sigmaT, tau, sigma, sigmaTSC, tauSC, sigmaSC, siteSigmaT, siteSigma
    
    #
    # function of reading coefficients
    def ReadModelCoefs(self):
        self.CoefKeys = open(self.CoefFile,'r').readlines()[0].strip().split(',')[1:]
        inputs = np.loadtxt(self.CoefFile, skiprows=1, delimiter=',')
        self.periods = inputs[:,0]
        coefs = inputs[:,1:]
        for i in range( len(self.periods) ):
            T1 = self.periods[i]
            Tkey = GetKey(T1)
            
            # assign to Coefs
            self.Coefs[Tkey] = {}
            for ikey in range(len(self.CoefKeys)):
                key = self.CoefKeys[ikey]
                cmd = "self.Coefs['%s']['%s'] = coefs[%i,%i]"%(Tkey,key,i,ikey)
                exec(cmd)
        
    #
    def moment_function(self, Tother=None):
        """
        Magnitude-Moment scaling
        """
        #
        #
        if Tother != None:
            Ti = GetKey(Tother)
        else:
            Ti = GetKey(self.T)
        #
        ccr = self.Coefs[Ti]['ccr']
        pcr = self.Coefs[Ti]['pcr']
        dcr = self.Coefs[Ti]['dcr']
        FNM = self.Coefs[Ti]['FNM']
        FRV = self.Coefs[Ti]['FRV']
        FSS = self.Coefs[Ti]['FSS']
        bcr = self.Coefs[Ti]['bcr']
        
        #
        if (self.M <=7.1):
            term=bcr*self.depth+ccr*self.M+pcr*(self.M-6.3)**2                 + FNM*self.NM + FSS*self.SS + FRV*self.RV
        else:
            term=bcr*self.depth+ccr*7.1   +pcr*(7.1-6.3)**2   +dcr*(self.M-7.1)+ FNM*self.NM + FSS*self.SS + FRV*self.RV
        
        #
        return term 
    #
    def distance_function(self,Tother=None):
        """
        Distance function
        Geometrical spreading? (yes ~ ln(R))
        """
        if Tother != None:
            Ti = GetKey(Tother)
        else:
            Ti = GetKey(self.T)
        #
        c1 = self.Coefs[Ti]['c1']
        c2 = self.Coefs[Ti]['c2']
        gcr = self.Coefs[Ti]['gcr']
        gcrL = self.Coefs[Ti]['gcrL']
        gcrN = self.Coefs[Ti]['gcrN']
        ecr = self.Coefs[Ti]['ecr']
        gamma = self.Coefs[Ti]['gamma']
        
        xo = 4.0
        #
        r = xo + self.Dist + np.exp(c1 + c2*min(7.1, self.M))
        r_near = xo + min(40, self.Dist) + np.exp(c1 + c2*min(7.1, self.M))
        term = gcr*np.log(r) + gcrL*np.log(self.Dist+150.0) + gcrN*np.log(r_near) + ecr*self.Dist + gamma
        
        #
        return term
    #
    def site_function(self, SC=None, Tother=None):
        """
        Site Amplification Function
        """
        if SC != None: 
            self.SC = SC 
        #
        if Tother != None: 
            Ti = GetKey( Tother )
            T = Tother
        else: 
            Ti = GetKey(self.T )
            T = self.T 
        #
        # extract coefficients
        AmSCI = self.Coefs[Ti]['AmSCI']
        LnSCIAm = np.log(AmSCI)
        
        S2 = self.Coefs[Ti]['S2']
        S3 = self.Coefs[Ti]['S3']
        S4 = self.Coefs[Ti]['S4']
        
        CA_I = self.Coefs[Ti]['CA_I']
        CA_II = self.Coefs[Ti]['CA_II']
        CA_III = self.Coefs[Ti]['CA_III']
        CA_IV = self.Coefs[Ti]['CA_IV']
        beta = self.Coefs[Ti]['beta']
        
        #
        # compute rock spectrum
        SaSCI = self.moment_function()+self.distance_function()
        self.Sarock = np.exp(SaSCI - LnSCIAm)
        
        #
        # compute linear site amplification ratio
        if (self.SC == 'I' or self.SC == 1 ):
            Anmax=np.exp(LnSCIAm)
            CA = CA_I
        elif (self.SC == 'II'  or self.SC == 2):
            Anmax=np.exp(LnSCIAm+S2)
            CA = CA_II
        elif (self.SC == 'III'  or self.SC == 3):
            Anmax=np.exp(LnSCIAm+S3)
            CA = CA_III
        elif (self.SC == 'IV'  or self.SC == 4):                                       # (self.SC == 'IV')
            Anmax=np.exp(LnSCIAm+S4)
            CA = CA_IV
        
        # 
        if self.SCNL == 0 :                         # return if linear spectrum is requested
            self.Fsite=Anmax
            return self.Sarock, self.Fsite
        else:
            lnAn=np.log(Anmax) + CA * np.log((self.Sarock+beta)/beta)
            self.Fsite = np.exp(lnAn)
        
        #
        return self.Sarock, self.Fsite
    
    #
    def compute_im(self,terms=(1,1,1)):
        """
        Compute IM based on functional form of BA08 model
        note: for PGA and PSA, IM has unit (g) here 
        """
        
        Sarock, Fsite = self.site_function()
        IM = Sarock*Fsite
        
        return IM
    
    #
    def compute_std(self):
        Ti = GetKey(self.T)
        sigmaT = self.Coefs[Ti]['sigmaT']
        tau = self.Coefs[Ti]['tau']
        phai = self.Coefs[Ti]['phai']
        
        if (self.SC == 'I' or self.SC == 1):
            tauSC = self.Coefs[Ti]['tauS_I']
            sigmaSC = self.Coefs[Ti]['phaiS_I']
        elif (self.SC == 'II'  or self.SC == 2):
            tauSC = self.Coefs[Ti]['tauS_II']
            sigmaSC = self.Coefs[Ti]['phaiS_II']
        elif (self.SC == 'III'  or self.SC == 3):
            tauSC = self.Coefs[Ti]['tauS_III']
            sigmaSC = self.Coefs[Ti]['phaiS_III']
        elif (self.SC == 'IV'  or self.SC == 4):
            tauSC = self.Coefs[Ti]['tauS_IV']
            sigmaSC = self.Coefs[Ti]['phaiS_IV']
        
        #
        sigmaTSC = np.sqrt(tauSC**2 + sigmaSC**2)
        siteSigmaT= np.sqrt(sigmaTSC**2+tau**2)
        siteSigma= np.sqrt(sigmaSC**2+tau**2)
        
        return sigmaT, tau, phai, sigmaTSC, tauSC, sigmaSC, siteSigmaT, siteSigma
#
#
def attenuation_curve(M=6.6, depth=1.0, SC='II', T=0.005, Mech=1, SCNL = 1):
    
    Dist_arr = np.geomspace(1,400,40)
    
    oneSeries=[]
    for aDist in Dist_arr:
        aHou25GMM = GMM_Hou25_SWC()
        values = aHou25GMM( M, aDist, SC, T, depth=depth, Mech=Mech)
        oneSeries.append(values)
    
    Att_data_Arr = np.array(oneSeries)
    Att_data_Arr = np.column_stack((Dist_arr, Att_data_Arr))
    
    return Att_data_Arr
#
#
def Mw_scaling( depth=1.0, Dist=10, SC = 'II', T = 0.005, Mech=1, SCNL = 1):
    
    Mw_arr = np.linspace(4.5,8.0,30)
    oneSeries=[]
    for M in Mw_arr:
        aHou25GMM = GMM_Hou25_SWC()
        values = aHou25GMM( M, Dist, SC, T, depth=depth, Mech=Mech)
        oneSeries.append(values)
    
    Mw_data_Arr = np.array(oneSeries)
    Mw_data_Arr = np.column_stack((Mw_arr, Mw_data_Arr))
    
    return Mw_data_Arr
#
#
def Spec_vs_period(M=6.6, depth=1.0, Dist=10, SC = 'II', Mech=1, T = None, SCNL = 1):
    
    if T is None:
        T = [0.005,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,
                    0.12,0.14,0.15,0.16,0.18,0.2,
                    0.25,0.3,0.35,0.4,0.45,0.5,
                    0.6,0.7,0.8,0.9,1.0,1.25,1.5,2.0,
                    2.5,3.0,3.5,4.0,4.5,5.0,6.0,7.0,8.0,10.0]
    
    
    oneSeries=[]
    for aTp in T:
        aHou25GMM = GMM_Hou25_SWC()
        values = aHou25GMM( M, Dist, SC, aTp, depth=depth, Mech=Mech)
        oneSeries.append(values)
    
    period_data_Arr = np.array(oneSeries)
    period_data_Arr = np.column_stack((T, period_data_Arr))
    
    return period_data_Arr
#

